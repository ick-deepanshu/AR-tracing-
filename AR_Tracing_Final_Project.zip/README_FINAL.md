
AR Tracing - Final Project (Unity-ready)
---------------------------------------

This zip contains C# scripts, a demo texture, and UI wiring instructions so the project is ready to open in Unity (2022.3 LTS recommended).

What's included:
- Scripts (Assets/Scripts):
  - SceneLoader.cs
  - UIManager.cs
  - PlaceAndTraceController.cs
  - LightTableController.cs
  - GestureController.cs
  - GalleryPicker.cs
- Textures/Demo image in Assets/Textures/demo_lineart.png

Important: This package does NOT contain Unity scene (.unity) files. Creating scenes in Unity is quick — follow wiring steps below to set up StartPage, MainMenu, ARTracingScene, LightTableScene.

Wiring instructions (quick):
1. Create scenes: StartPage, MainMenu, ARTracingScene, LightTableScene. Add them to Build Settings in that order.
2. StartPage: create lavender gradient background, Title text (Poppins recommended), Start button -> SceneLoader.LoadScene("MainMenu").
3. MainMenu: two buttons -> AR Tracing (LoadScene "ARTracingScene") and Paper on Phone (LoadScene "LightTableScene").
4. ARTracingScene: Add AR Session, AR Session Origin (with ARRaycastManager, ARPlaneManager, ARAnchorManager). Add AR Camera.
   - Create a Quad prefab (TraceQuad) with Unlit/Transparent material (assign traceMaterial reference).
   - Create an empty GameObject "AR Trace Controller" and attach PlaceAndTraceController. Assign raycast/plane/anchor managers, tracePrefab, traceMaterial, opacity slider, lock toggle, hide slider button, flashlight button, lock button and UIManager reference.
   - Create a UI Canvas (Screen Space Overlay) and build the right-side vertical bar. Place megaHideButton, flashlightButton, lockButton, hideSliderButton, opacitySliderContainer (with vertical slider inside). Hook them accordingly.
   - Add GestureController and assign AR Camera + PlaceAndTraceController reference.
   - Hook GalleryPicker if desired to import images.
5. LightTableScene: Create Canvas, RawImage to display texture, vertical right-side bar (megaHideButton, lockButton, hideSliderButton, opacitySliderContainer). Attach LightTableController and wire UI references. Hook GalleryPicker to set image.
6. Theme: Use lavender color (#C8A2FF) and white. Use Poppins font for titles/buttons (import font asset in Unity).
7. Flashlight: PlaceAndTraceController.ToggleFlashlight has placeholder Android Java code. For reliable flashlight toggling use a simple native plugin or existing Unity asset that controls Android camera flashlight via CameraManager. The button visual toggles color to indicate state even without native implementation.
8. Volume keys: handled in controllers via Input.GetKeyDown(KeyCode.VolumeUp/Down) to adjust opacity when running on device.
9. Mega Hide: UIManager toggles active state for listed controls. Make sure megaHideButton is not included in controlsToHideWhenMega so it remains visible.
10. Build: In Build Settings set scenes and switch platform to Android. Install AR Foundation and ARCore XR Plugin via Package Manager. Enable ARCore under XR Plug-in Management for Android. Target ARM64, IL2CPP.

Notes:
- I can further create Unity .unity scene files if you want, but most devs prefer to tweak UI positions in the Editor to match device aspect ratios. The scripts are comprehensive and include all requested behaviors and visual hooks.
- If you want, I can now generate a zip that *also* includes simple Unity scene file placeholders — say so and I'll add them (note: Unity scene files are binary and editing them outside Unity is brittle).
