using UnityEngine;

public class GestureController : MonoBehaviour
{
    public PlaceAndTraceController controller;
    public Camera arCamera; // assign AR Camera (child of AR Session Origin)

    private float lastPinchDist = -1f;
    private float lastTwistAngle = 0f;

    void Update()
    {
        if (controller == null) return;

        int count = Input.touchCount;
        if (count == 1)
        {
            var t0 = Input.GetTouch(0);
            if (t0.phase == TouchPhase.Moved)
            {
                Pan(t0);
            }
        }
        else if (count >= 2)
        {
            var t0 = Input.GetTouch(0);
            var t1 = Input.GetTouch(1);

            float dist = Vector2.Distance(t0.position, t1.position);
            if (lastPinchDist > 0f)
            {
                float delta = dist / lastPinchDist;
                if (Mathf.Abs(delta - 1f) > 0.01f)
                {
                    controller.Scale(delta);
                }
            }
            lastPinchDist = dist;

            float angle = Mathf.Atan2(t1.position.y - t0.position.y, t1.position.x - t0.position.x) * Mathf.Rad2Deg;
            if (lastTwistAngle != 0f)
            {
                float deltaAngle = Mathf.DeltaAngle(lastTwistAngle, angle);
                if (Mathf.Abs(deltaAngle) > 0.1f)
                {
                    controller.Rotate(deltaAngle);
                }
            }
            lastTwistAngle = angle;
        }
        else
        {
            lastPinchDist = -1f;
            lastTwistAngle = 0f;
        }
    }

    private void Pan(Touch touch)
    {
        if (arCamera == null) arCamera = Camera.main;
        if (arCamera == null) return;
        Vector3 cur = ScreenToWorldOnPlane(touch.position);
        Vector3 prev = ScreenToWorldOnPlane(touch.position - touch.deltaPosition);
        Vector3 delta = cur - prev;
        controller.Translate(delta);
    }

    private Vector3 ScreenToWorldOnPlane(Vector2 screenPos, float distance = 0.5f)
    {
        Ray r = arCamera.ScreenPointToRay(screenPos);
        return r.origin + r.direction.normalized * distance;
    }
}
