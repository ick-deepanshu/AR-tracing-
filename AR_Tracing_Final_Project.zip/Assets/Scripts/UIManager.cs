using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class UIManager : MonoBehaviour
{
    [Header("Right Bar Controls (order independent)")]
    public GameObject megaHideButton; // keep visible when mega hide toggled
    public List<GameObject> controlsToHideWhenMega = new List<GameObject>(); // other right bar controls + back button
    public Button megaHideBtn;
    public bool isMegaHidden = false;

    void Start()
    {
        if (megaHideBtn != null) megaHideBtn.onClick.AddListener(ToggleMegaHide);
    }

    public void ToggleMegaHide()
    {
        isMegaHidden = !isMegaHidden;
        foreach (var go in controlsToHideWhenMega)
        {
            if (go != null) go.SetActive(!isMegaHidden);
        }

        var img = megaHideButton != null ? megaHideButton.GetComponent<UnityEngine.UI.Image>() : null;
        if (img != null)
        {
            img.color = isMegaHidden ? new Color(0.8f, 0.6f, 0.9f, 1f) : Color.white;
        }
    }
}
