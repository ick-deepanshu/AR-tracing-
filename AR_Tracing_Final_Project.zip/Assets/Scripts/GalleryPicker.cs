using UnityEngine;
using System.IO;

public class GalleryPicker : MonoBehaviour
{
    public PlaceAndTraceController controller;
    public LightTableController lightTableController;

    public void PickImage()
    {
        #if USE_NATIVE_GALLERY
        NativeGallery.Permission perm = NativeGallery.GetImageFromGallery((path) =>
        {
            if (path == null) return;
            var tex = LoadTextureFromPath(path);
            if (tex != null)
            {
                if (controller != null) controller.SetImage(tex);
                if (lightTableController != null) lightTableController.SetImage(tex);
            }
        }, "Select image to trace", "image/*");
        #else
        Debug.Log("NativeGallery not present. Add plugin and define USE_NATIVE_GALLERY to enable.");
        #endif
    }

    private Texture2D LoadTextureFromPath(string path)
    {
        if (!File.Exists(path)) return null;
        byte[] bytes = File.ReadAllBytes(path);
        Texture2D tex = new Texture2D(2,2,TextureFormat.RGBA32,false);
        if (tex.LoadImage(bytes)) return tex;
        return null;
    }
}
