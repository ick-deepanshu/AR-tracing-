using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class LightTableController : MonoBehaviour
{
    public RawImage displayImage;
    public Slider opacitySlider;
    public Toggle lockToggle;
    public GameObject opacitySliderContainer;
    public Button hideSliderButton;
    public Button lockButton;
    public UIManager uiManager;

    private Texture2D currentTexture;
    private bool isLocked = false;

    void Start()
    {
        if (opacitySlider != null)
        {
            opacitySlider.onValueChanged.AddListener(OnOpacityChanged);
            OnOpacityChanged(opacitySlider.value);
        }
        if (lockToggle != null)
        {
            lockToggle.onValueChanged.AddListener(OnLockChanged);
            lockToggle.isOn = isLocked;
        }
        if (hideSliderButton != null && opacitySliderContainer != null)
        {
            hideSliderButton.onClick.AddListener(ToggleSliderVisibility);
        }
        StartCoroutine(SetMaxBrightness());
    }

    private IEnumerator SetMaxBrightness()
    {
        #if UNITY_ANDROID && !UNITY_EDITOR
        Screen.brightness = 1f;
        #endif
        yield return null;
    }

    void Update()
    {
        HandleVolumeKeysForOpacity();
    }

    private void HandleVolumeKeysForOpacity()
    {
        if (Input.GetKeyDown(KeyCode.VolumeUp))
        {
            ChangeOpacityByStep(0.05f);
        }
        else if (Input.GetKeyDown(KeyCode.VolumeDown))
        {
            ChangeOpacityByStep(-0.05f);
        }
    }

    private void ChangeOpacityByStep(float step)
    {
        if (opacitySlider != null)
        {
            opacitySlider.value = Mathf.Clamp01(opacitySlider.value + step);
        }
    }

    public void OnOpacityChanged(float v)
    {
        if (displayImage != null)
        {
            Color c = displayImage.color;
            c.a = Mathf.Clamp01(v);
            displayImage.color = c;
        }
    }

    public void OnLockChanged(bool locked)
    {
        isLocked = locked;
        if (lockButton != null)
        {
            var img = lockButton.GetComponent<UnityEngine.UI.Image>();
            if (img != null) img.color = locked ? new Color(0.8f,0.6f,0.9f,1f) : Color.white;
        }
    }

    public void ToggleSliderVisibility()
    {
        if (opacitySliderContainer != null)
        {
            opacitySliderContainer.SetActive(!opacitySliderContainer.activeSelf);
        }
    }

    public void SetImage(Texture2D tex)
    {
        currentTexture = tex;
        if (displayImage != null)
        {
            displayImage.texture = currentTexture;
        }
    }
}
