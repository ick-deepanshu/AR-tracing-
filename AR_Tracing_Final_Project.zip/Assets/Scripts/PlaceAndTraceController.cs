using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class PlaceAndTraceController : MonoBehaviour
{
    [Header("AR Managers (from AR Session Origin)")]
    public ARRaycastManager raycastManager;
    public ARPlaneManager planeManager;
    public ARAnchorManager anchorManager;

    [Header("Placement & Visuals")]
    public GameObject tracePrefab;         // A Quad with Unlit/Transparent material
    public Material traceMaterial;         // Material template used on the Quad
    public bool startLocked = false;       // Start with the placed image locked

    [Header("UI")]
    public Slider opacitySlider;
    public Toggle lockToggle;
    public GameObject opacitySliderContainer; // used for hide/show slider UI
    public Button hideSliderButton; // toggles slider container
    public Button flashlightButton; // toggles flashlight
    public Button lockButton; // visual lock button that can change appearance
    public UIManager uiManager; // for mega hide interactions

    private static List<ARRaycastHit> s_Hits = new List<ARRaycastHit>();

    private GameObject placedVisual;       // The visible quad
    private ARAnchor anchor;               // Anchor holding position in world
    private bool isLocked;
    private bool flashlightOn = false;

    private Texture2D currentTexture;

    void Start()
    {
        isLocked = startLocked;
        if (opacitySlider != null)
        {
            opacitySlider.onValueChanged.AddListener(SetOpacity);
            SetOpacity(opacitySlider.value);
        }
        if (lockToggle != null)
        {
            lockToggle.onValueChanged.AddListener(SetLocked);
            lockToggle.isOn = startLocked;
        }
        if (hideSliderButton != null && opacitySliderContainer != null)
        {
            hideSliderButton.onClick.AddListener(ToggleSliderVisibility);
        }
        if (flashlightButton != null)
        {
            flashlightButton.onClick.AddListener(ToggleFlashlight);
        }
    }

    void Update()
    {
        HandleVolumeKeysForOpacity();

        if (isLocked) return;

        if (Input.touchCount > 0)
        {
            var touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Began)
            {
                TryPlaceOrMoveAt(touch.position);
            }
        }
    }

    private void HandleVolumeKeysForOpacity()
    {
        if (Input.GetKeyDown(KeyCode.VolumeUp))
        {
            ChangeOpacityByStep(0.05f);
        }
        else if (Input.GetKeyDown(KeyCode.VolumeDown))
        {
            ChangeOpacityByStep(-0.05f);
        }
    }

    private void ChangeOpacityByStep(float step)
    {
        if (opacitySlider != null)
        {
            opacitySlider.value = Mathf.Clamp01(opacitySlider.value + step);
        }
        else
        {
            SetOpacity(Mathf.Clamp01((traceMaterial != null ? traceMaterial.color.a : 1f) + step));
        }
    }

    private void TryPlaceOrMoveAt(Vector2 screenPos)
    {
        if (raycastManager == null) return;

        if (raycastManager.Raycast(screenPos, s_Hits, TrackableType.PlaneWithinPolygon))
        {
            var hit = s_Hits[0];
            Pose pose = hit.pose;

            if (anchor == null)
            {
                anchor = anchorManager != null
                    ? anchorManager.AttachAnchor(planeManager.GetPlane(hit.trackableId), pose)
                    : null;

                if (anchor == null)
                {
                    var go = new GameObject("TraceAnchor");
                    go.transform.position = pose.position;
                    go.transform.rotation = pose.rotation;
                    anchor = go.AddComponent<ARAnchor>();
                }
            }
            else
            {
                anchor.transform.SetPositionAndRotation(pose.position, pose.rotation);
            }

            if (placedVisual == null)
            {
                placedVisual = Instantiate(tracePrefab, pose.position, pose.rotation);
                placedVisual.name = "TraceQuad";
                placedVisual.transform.SetParent(anchor.transform, worldPositionStays: true);
                ApplyTextureToVisual();
            }
            else
            {
                placedVisual.transform.SetPositionAndRotation(pose.position, pose.rotation);
            }
        }
    }

    public void SetLocked(bool locked)
    {
        isLocked = locked;
        if (lockButton != null)
        {
            var img = lockButton.GetComponent<UnityEngine.UI.Image>();
            if (img != null) img.color = locked ? new Color(0.8f,0.6f,0.9f,1f) : Color.white;
        }
    }

    public void ToggleLocked()
    {
        SetLocked(!isLocked);
        if (lockToggle != null) lockToggle.isOn = isLocked;
    }

    public void SetOpacity(float alpha)
    {
        if (traceMaterial != null)
        {
            var c = traceMaterial.color;
            c.a = Mathf.Clamp01(alpha);
            traceMaterial.color = c;
            if (placedVisual != null)
            {
                var mr = placedVisual.GetComponent<MeshRenderer>();
                if (mr != null && mr.material != null)
                {
                    Color ic = mr.material.color;
                    ic.a = Mathf.Clamp01(alpha);
                    mr.material.color = ic;
                }
            }
        }
    }

    public void SetImage(Texture2D tex)
    {
        currentTexture = tex;
        ApplyTextureToVisual();
    }

    private void ApplyTextureToVisual()
    {
        if (tracePrefab == null || traceMaterial == null) return;
        if (placedVisual == null) return;

        var mr = placedVisual.GetComponent<MeshRenderer>();
        if (mr != null)
        {
            var instancedMat = new Material(traceMaterial);
            if (currentTexture != null)
            {
                instancedMat.mainTexture = currentTexture;
                float w = currentTexture.width;
                float h = currentTexture.height;
                if (h > 0)
                {
                    float aspect = w / h;
                    Vector3 s = placedVisual.transform.localScale;
                    placedVisual.transform.localScale = new Vector3(s.y * aspect, s.y, s.z);
                }
            }
            mr.material = instancedMat;
            Color c = mr.material.color;
            c.a = Mathf.Clamp01(opacitySlider != null ? opacitySlider.value : c.a);
            mr.material.color = c;
        }
    }

    public void Translate(Vector3 worldDelta)
    {
        if (isLocked || placedVisual == null) return;
        placedVisual.transform.position += worldDelta;
        if (anchor != null) anchor.transform.position = placedVisual.transform.position;
    }

    public void Rotate(float degrees)
    {
        if (isLocked || placedVisual == null) return;
        placedVisual.transform.Rotate(Vector3.up, degrees, Space.World);
        if (anchor != null) anchor.transform.rotation = placedVisual.transform.rotation;
    }

    public void Scale(float scaleMultiplier)
    {
        if (isLocked || placedVisual == null) return;
        placedVisual.transform.localScale *= scaleMultiplier;
    }

    public void ToggleSliderVisibility()
    {
        if (opacitySliderContainer != null)
        {
            opacitySliderContainer.SetActive(!opacitySliderContainer.activeSelf);
        }
    }

    public void ToggleFlashlight()
    {
        flashlightOn = !flashlightOn;
        if (flashlightButton != null)
        {
            var img = flashlightButton.GetComponent<UnityEngine.UI.Image>();
            if (img != null) img.color = flashlightOn ? new Color(0.8f,0.6f,0.9f,1f) : Color.white;
        }

        #if UNITY_ANDROID && !UNITY_EDITOR
        try
        {
            AndroidJavaClass cameraClass = new AndroidJavaClass("android.hardware.Camera");
            // Placeholder: real flashlight control requires a plugin or CameraManager usage.
        }
        catch (System.Exception e)
        {
            Debug.LogWarning("Flashlight toggle failed: " + e.Message);
        }
        #else
        Debug.Log("Flashlight toggle only available on Android device at runtime.");
        #endif
    }
}
